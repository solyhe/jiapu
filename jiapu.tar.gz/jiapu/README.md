# 家谱树 · 轻量家谱平台

Alpine + Python 标准库 + SQLite3，零第三方依赖。镜像约 45–50MB，运行内存约 15–25MB。

## 启动
```bash
docker compose up -d --build        # 访问 http://服务器IP:8080
# 或
docker build -t jiapu . && docker run -d --name jiapu -p 8080:8080 -v $PWD/data:/data jiapu
```
数据库在 `./data/family.db`（WAL 模式），直接拷贝该目录即可整体备份。

## 环境变量
| 变量 | 默认 | 说明 |
|---|---|---|
| AUTH_PASS | 空 | 设置后启用 HTTP Basic 登录（用户名见 AUTH_USER） |
| AUTH_USER | admin | 登录用户名 |
| READ_PUBLIC | 0 | 1=未登录可只读浏览，编辑需点「登录编辑」 |
| MAX_BACKUPS | 50 | 每个家谱保留的服务器备份数 |
| PORT / DB_PATH | 8080 / /data/family.db | 端口与数据库路径 |
公网部署请放在 HTTPS 反向代理（Nginx/Caddy）后面，Basic 认证才安全。

## 功能
- 多家谱管理（新建/重命名/删除/切换）
- 竖排姓名卡片树：男蓝、女粉、已故灰、配偶虚线框，排行角标，夫/妻标签
- 拖动平移、滚轮/双指缩放、适应窗口、姓名搜索（回车跳到下一个）
- 编辑成员：姓名、性别、在世/已故、生卒年、字辈、籍贯、职业、生平简介
- 添加子女 / 同胞 / 配偶 / 父母，批量加子女，前移/后移调整排行，删除（连带后代）
- 自动显示：第 N 代、长子/次女、子女数、配偶、生卒
- 撤销（Ctrl+Z，80 步）、自动保存到 SQLite、多人同时编辑冲突检测
- 统计：人数、代数、男女、在世/已故、平均寿命、各代人数、姓氏、字辈
- 存到文件/打开（JSON）、导出图片（PNG）、打印、导出/导入表格（CSV，Excel 可直接打开）
- 服务器备份/恢复/下载，清空、导入、恢复前自动备份
- 竖排/横排切换，手机端编辑面板变底部抽屉

## API
`GET/POST /api/trees` · `GET/PUT/PATCH/DELETE /api/trees/{id}` · `GET/POST /api/trees/{id}/backups` · `POST /api/backups/{id}/restore` · `GET /api/backups/{id}/download` · `DELETE /api/backups/{id}`
